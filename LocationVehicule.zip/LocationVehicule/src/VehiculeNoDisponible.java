public class VehiculeNoDisponible extends Exception {
    public VehiculeNoDisponible(String messages) {

        super(messages);
    }
}
