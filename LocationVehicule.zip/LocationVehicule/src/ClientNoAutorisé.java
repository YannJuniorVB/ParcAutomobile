public class ClientNoAutorisé extends Exception {
    public ClientNoAutorisé(String message){
        super (message);
    }
}
