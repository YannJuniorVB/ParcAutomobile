public interface InterfaceLouable {
        public void louer () throws VehiculeNoDisponible;
        public void retourner ();
}
